import os
import numpy as np
from dataset import get_data,normalize

from matplotlib import pyplot as plt

import torch
from torch import nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset

# Define the LeNet model
class LeNet(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(1, 6, kernel_size=5)
        self.pool = nn.MaxPool2d(kernel_size=2)
        self.conv2 = nn.Conv2d(6, 16, kernel_size=5)
        self.fc1 = nn.Linear(16*5*5, 120)
        self.fc2 = nn.Linear(120, 84)
        self.fc3 = nn.Linear(84, 10)

    def forward(self, x):
        x = self.pool(torch.relu(self.conv1(x)))
        x = self.pool(torch.relu(self.conv2(x)))
        x = x.view(-1, 16*5*5)
        x = torch.relu(self.fc1(x))
        conv = x
        x = torch.relu(self.fc2(x))
        fc = x
        x = self.fc3(x)
        return x, conv, fc
    
class MyNet(nn.Module):
    def __init__(self):
        super().__init__()
        
        # First convolutional layer
        self.conv1 = nn.Conv2d(in_channels=1, out_channels=32, kernel_size=3, stride=1, padding=1)
        self.relu1 = nn.ReLU()
        self.pool1 = nn.MaxPool2d(kernel_size=2, stride=2)
        self.bn1 = nn.BatchNorm2d(32)
        
        # Second convolutional layer
        self.conv2 = nn.Conv2d(in_channels=32, out_channels=64, kernel_size=3, stride=1, padding=1)
        self.relu2 = nn.ReLU()
        self.pool2 = nn.MaxPool2d(kernel_size=2, stride=2)
        self.bn2 = nn.BatchNorm2d(64)
        
        # Third convolutional layer
        self.conv3 = nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1)
        self.relu3 = nn.ReLU()
        self.bn3 = nn.BatchNorm2d(64)
        
        # Flatten the output of the convolutional layers
        self.flatten = nn.Flatten()
        
        # First fully connected layer
        self.fc1 = nn.Linear(in_features=64 * 8 * 8, out_features=128)
        self.relu4 = nn.ReLU()
        
        # Output layer
        self.fc2 = nn.Linear(in_features=128, out_features=10)
        
    def forward(self, x):
        x = self.conv1(x)
        x = self.relu1(x)
        x = self.pool1(x)
        x = self.bn1(x)
        
        x = self.conv2(x)
        x = self.relu2(x)
        x = self.pool2(x)
        x = self.bn2(x)
        
        x = self.conv3(x)
        x = self.relu3(x)
        x = self.bn3(x)
        conv = x
        
        x = self.flatten(x)
        
        x = self.fc1(x)
        x = self.relu4(x)
        fc = x
        
        x = self.fc2(x)
        
        return x, conv, fc

#PCA

def pca(X, n_components=2):
    X_mean = np.mean(X, axis=0)
    X_centered = X - X_mean
    U, S, Vt = np.linalg.svd(X_centered)
    W = Vt.T[:, :n_components]
    X_pca = X_centered @ W
    return X_pca

#tSNE

def cal_pairwise_dist(x):
    sum_x = np.sum(np.square(x), 1)
    dist = np.add(np.add(-2 * np.dot(x, x.T), sum_x).T, sum_x)
    return dist

def cal_perplexity(dist, idx=0, beta=1.0):
    prob = np.exp(-dist * beta)
    prob[idx] = 0
    sum_prob = np.sum(prob)
    if sum_prob == 0:
        prob = np.maximum(prob, 1e-12)
        perp = -12
    else:
        prob /= sum_prob
        perp = 0
        for pj in prob:
            if pj != 0:
                perp += -pj*np.log(pj)
    return perp, prob

def seach_prob(x, tol=1e-5, perplexity=30.0):
    # print("Computing pairwise distances...")
    (n, d) = x.shape
    dist = cal_pairwise_dist(x)
    pair_prob = np.zeros((n, n))
    beta = np.ones((n, 1))
    base_perp = np.log(perplexity)

    for i in range(n):
        # if i % 500 == 0:
        #     print("Computing pair_prob for point %s of %s ..." %(i,n))

        betamin = -np.inf
        betamax = np.inf
        perp, this_prob = cal_perplexity(dist[i], i, beta[i])

        perp_diff = perp - base_perp
        tries = 0
        while np.abs(perp_diff) > tol and tries < 50:
            if perp_diff > 0:
                betamin = beta[i].copy()
                if betamax == np.inf or betamax == -np.inf:
                    beta[i] = beta[i] * 2
                else:
                    beta[i] = (beta[i] + betamax) / 2
            else:
                betamax = beta[i].copy()
                if betamin == np.inf or betamin == -np.inf:
                    beta[i] = beta[i] / 2
                else:
                    beta[i] = (beta[i] + betamin) / 2

            perp, this_prob = cal_perplexity(dist[i], i, beta[i])
            perp_diff = perp - base_perp
            tries = tries + 1
        
        pair_prob[i,] = this_prob
    # print("Mean value of sigma: ", np.mean(np.sqrt(1 / beta)))
    return pair_prob

def tsne(x, no_dims=2, initial_dims=50, perplexity=30.0, max_iter=800):
    # Runs t-SNE on the dataset in the NxD array x
    # to reduce its dimensionality to no_dims dimensions.
    # The syntaxis of the function is Y = tsne.tsne(x, no_dims, perplexity),
    # where x is an NxD NumPy array.

    # Check inputs
    if isinstance(no_dims, float):
        print("Error: array x should have type float.")
        return -1
    if round(no_dims) != no_dims:
        print("Error: number of dimensions should be an integer.")
        return -1

    (n, d) = x.shape
    print (x.shape)

    eta = 500
    y = np.random.randn(n, no_dims)
    # gradient of dy
    dy = np.zeros((n, no_dims))
    P = seach_prob(x, 1e-5, perplexity)
    P = P + np.transpose(P)
    P = P / np.sum(P)  
    P = P * 4
    P = np.maximum(P, 1e-12)

    # Run iterations
    for iter in range(max_iter):
        # Compute pairwise affinities
        sum_y = np.sum(np.square(y), 1)
        num = 1 / (1 + np.add(np.add(-2 * np.dot(y, y.T), sum_y).T, sum_y))
        num[range(n), range(n)] = 0
        Q = num / np.sum(num)   
        Q = np.maximum(Q, 1e-12)   

        # Compute gradient
        PQ = P - Q
        #gradient of dy
        for i in range(n):
            dy[i,:] = np.sum(np.tile(PQ[:,i] * num[:,i], (no_dims, 1)).T * (y[i,:] - y), 0)
        
        # update y
        y = y - eta*dy
        
        y = y - np.tile(np.mean(y, 0), (n, 1))
        # Compute current value of cost function
        if (iter + 1) % 50 == 0:
            if iter > 100:
                C = np.sum(P * np.log(P / Q))
            else:
                C = np.sum( P/4 * np.log( P/4 / Q))
            # print("Iteration ", (iter + 1), ": error is ", C)
        # Stop lying about P-values
        if iter == 100:
            P = P / 4
    # print("finished training!")
    return y

def visualize(sampleset, labelset):
    features = sampleset
    labels = labelset.numpy()
    features = features.reshape(1000,-1)
    print(features.shape)
    pca_result = pca(features)
    tsne_result = tsne(features, 2, 50, 20.0)
    plt.scatter(pca_result[:, 0], pca_result[:, 1], c=labels, cmap='viridis')
    plt.title("PCA Visualization")
    plt.show()

    plt.scatter(tsne_result[:, 0], tsne_result[:, 1], c=labels, cmap='viridis')
    plt.title("t-SNE Visualization")
    plt.show()

if __name__ == '__main__':
    ######################## Get train/test dataset ########################
    X_train, X_test, Y_train, Y_test = get_data('dataset')
    ########################################################################
    # 以上加载的数据为 numpy array格式
    # 如果希望使用pytorch或tensorflow等库，需要使用相应的函数将numpy arrray转化为tensor格式
    # 以pytorch为例：
    #   使用torch.from_numpy()函数可以将numpy array转化为pytorch tensor
    #
    # Hint:可以考虑使用torch.utils.data中的class来简化划分mini-batch的操作，比如以下class：
    #   https://pytorch.org/docs/stable/data.html#torch.utils.data.TensorDataset
    #   https://pytorch.org/docs/stable/data.html#torch.utils.data.DataLoader
    ########################################################################

    ########################################################################
    ######################## Implement you code here #######################
    ########################################################################
    # Convert the NumPy arrays to PyTorch tensors
    X_train = torch.from_numpy(X_train).float()
    Y_train = torch.from_numpy(Y_train).long()
    X_test = torch.from_numpy(X_test).float()
    Y_test = torch.from_numpy(Y_test).long()    
    
    # ################ LeNet ##################

    # Create a DataLoader for the training data
    trainset = torch.utils.data.TensorDataset(X_train, Y_train)
    train_loader = torch.utils.data.DataLoader(trainset, batch_size=32, shuffle=True)

    # Create a DataLoader for the test data
    testset = torch.utils.data.TensorDataset(X_test, Y_test)
    test_loader = torch.utils.data.DataLoader(testset, batch_size=32, shuffle=False)
    # Instantiate the LeNet model
    lenet = LeNet()

    # Define the loss function and optimizer
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.SGD(lenet.parameters(), lr=0.001, momentum=0.9)
    
    train_loss = []
    test_loss = []

    train_acc = []
    test_acc = []    
    # Train the network
    for epoch in range(200):
        running_loss = 0.0
        for i, data in enumerate(train_loader, 0):
            inputs, labels = data
            optimizer.zero_grad()
            outputs, _, __ = lenet(inputs)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()
            running_loss += loss.item()
        
        # Print the average loss for each epoch
        # print('Epoch %d, loss: %.3f' % (epoch + 1, running_loss / len(train_loader)))
        train_loss.append(running_loss / len(train_loader))
        
        running_loss = 0.0
        for i, data in enumerate(test_loader, 0):
            inputs, labels = data
            outputs, _, __ = lenet(inputs)
            loss = criterion(outputs, labels)
            running_loss += loss.item()
        
        # Print the average loss for each epoch
        # print('Epoch %d, loss: %.3f' % (epoch + 1, running_loss / len(test_loader)))
        test_loss.append(running_loss / len(test_loader))

        correct = 0
        total = 0
        with torch.no_grad():
            for data in train_loader:
                images, labels = data
                outputs, _, _ = lenet(images)
                _, predicted = torch.max(outputs.data, 1)
                total += labels.size(0)
                correct += (predicted == labels).sum().item()
        train_acc.append(correct / total)
        
        # Test the network
        correct = 0
        total = 0
        all_outputs = np.empty((0, 10))
        all_conv = np.empty((0, 120))
        all_fc = np.empty((0, 84))
        with torch.no_grad():
            for data in test_loader:
                images, labels = data
                outputs, conv, fc = lenet(images)
                all_outputs = np.concatenate((all_outputs, outputs.numpy()), axis=0)
                all_conv = np.concatenate((all_conv, conv.numpy()), axis=0)
                all_fc = np.concatenate((all_fc, fc.numpy()), axis=0)
                _, predicted = torch.max(outputs.data, 1)
                total += labels.size(0)
                correct += (predicted == labels).sum().item()
        test_acc.append(correct / total)

    # print('Accuracy on test set: %d %%' % (100 * correct / total))
    
    plt.plot(train_loss, label='Training Loss')
    plt.plot(test_loss, label='Testing Loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.legend()
    plt.show()
    
    plt.plot(train_acc, label='Training Accuracy')
    plt.plot(test_acc, label='Testing Accuracy')
    plt.xlabel('Epoch')
    plt.ylabel('Accuracy')
    plt.legend()
    plt.show()
    
    visualize(all_outputs, Y_test)
    visualize(all_fc, Y_test)
    visualize(all_conv, Y_test)
    
    ################ MyNet ##################
    
    # Convert the NumPy arrays to PyTorch tensors
    # Create a DataLoader for the training data
    trainset = torch.utils.data.TensorDataset(X_train, Y_train)
    train_loader = torch.utils.data.DataLoader(trainset, batch_size=32, shuffle=True)

    # Create a DataLoader for the test data
    testset = torch.utils.data.TensorDataset(X_test, Y_test)
    test_loader = torch.utils.data.DataLoader(testset, batch_size=32, shuffle=False)
    # Instantiate the MyNet model
    mynet = MyNet()

    # Define the loss function and optimizer
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.SGD(mynet.parameters(), lr=0.001, momentum=0.9)

    train_loss = []
    test_loss = []

    train_acc = []
    test_acc = []    
    # Train the network
    for epoch in range(200):
        running_loss = 0.0
        for i, data in enumerate(train_loader, 0):
            inputs, labels = data
            optimizer.zero_grad()
            outputs, _, __ = mynet(inputs)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()
            running_loss += loss.item()
        
        # Print the average loss for each epoch
        #print('Epoch %d, loss: %.3f' % (epoch + 1, running_loss / len(train_loader)))
        train_loss.append(running_loss / len(train_loader))

        running_loss = 0.0
        for i, data in enumerate(test_loader, 0):
            inputs, labels = data
            outputs, _, __ = mynet(inputs)
            loss = criterion(outputs, labels)
            running_loss += loss.item()
        
        # Print the average loss for each epoch
        #print('Epoch %d, loss: %.3f' % (epoch + 1, running_loss / len(test_loader)))
        test_loss.append(running_loss / len(test_loader))

        correct = 0
        total = 0
        with torch.no_grad():
            for data in train_loader:
                images, labels = data
                outputs, conv, fc = mynet(images)
                _, predicted = torch.max(outputs.data, 1)
                total += labels.size(0)
                correct += (predicted == labels).sum().item()

        train_acc.append(correct / total)
        
        # Test the network
        correct = 0
        total = 0
        all_outputs = np.empty((0, 10))
        all_conv = np.empty((0, 64, 8, 8))
        all_fc = np.empty((0, 128))
        with torch.no_grad():
            for data in test_loader:
                images, labels = data
                outputs, conv, fc = mynet(images)
                all_outputs = np.concatenate((all_outputs, outputs.numpy()), axis=0)
                all_conv = np.concatenate((all_conv, conv.numpy()), axis=0)
                all_fc = np.concatenate((all_fc, fc.numpy()), axis=0)
                _, predicted = torch.max(outputs.data, 1)
                total += labels.size(0)
                correct += (predicted == labels).sum().item()

        # print('Accuracy on test set: %d %%' % (100 * correct / total))
        test_acc.append(correct / total)
    
    plt.plot(train_loss, label='Training Loss')
    plt.plot(test_loss, label='Testing Loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.legend()
    plt.show()
    
    plt.plot(train_acc, label='Training Accuracy')
    plt.plot(test_acc, label='Testing Accuracy')
    plt.xlabel('Epoch')
    plt.ylabel('Accuracy')
    plt.legend()
    plt.show()
    
    visualize(all_outputs, Y_test)
    visualize(all_fc, Y_test)
    visualize(all_conv, Y_test)