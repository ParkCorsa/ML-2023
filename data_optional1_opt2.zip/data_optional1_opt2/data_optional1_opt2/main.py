import os
import numpy as np
from dataset import get_data,normalize

from matplotlib import pyplot as plt

if __name__ == '__main__':
    ######################## Get train dataset ########################
    X_train = get_data('dataset')
    ########################################################################
    ######################## Implement you code here #######################
    ########################################################################
